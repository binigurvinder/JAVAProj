package Backend;

public  class AppConsts 
{
	
	public static  final String URL="jdbc:mysql://localhost:3306/bank";
	public static  final String USERNAME="root";
	public static final String PASSWORD="Bini240794@@@";

}
