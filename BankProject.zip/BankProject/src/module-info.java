/**
 * 
 */
/**
 * 
 */
module BankProject {
	requires java.sql;
	requires java.desktop;
}